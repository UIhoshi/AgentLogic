// Auto-generated type stub — replace with real implementation
export type Select = any;
